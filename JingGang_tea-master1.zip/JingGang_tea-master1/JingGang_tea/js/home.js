
function showContent(id) {
    const intros = document.querySelectorAll('.tea-culture-intro');
    intros.forEach(intro => {
        intro.style.display = 'none';
    });
    const selectedIntro = document.getElementById(id);
    selectedIntro.style.display = 'block';

    const buttons = document.querySelectorAll('.tea-culture-button');
    buttons.forEach(button => {
        button.classList.remove('active');
    });
    const activeButton = document.querySelector(`[onclick="showContent('${id}')"]`);
    activeButton.classList.add('active');
}

function openPopup(id) {
    const popups = document.querySelectorAll('.popup');
    popups.forEach(popup => {
        popup.style.display = 'none';
    });
    const popup = document.getElementById(`popup-${id}`);
    popup.style.display = 'block';
}

function closePopup(id) {
    const popup = document.getElementById(`popup-${id}`);
    popup.style.display = 'none';
}